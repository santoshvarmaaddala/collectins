class ListNode:
    def __init__(self, val) -> None:
        self.val = val
        self.next = None

class LinkedList:
    
    def __init__(self, val) -> None:
        self.head: ListNode = ListNode(val)

    def append(self, val) -> None:
        if not self.head:
            self.head = ListNode(val)
            return 
     
        temp = self.head
        while temp.next:
            temp = temp.next
        temp.next = ListNode(val)