__version__ = '0.1.0'

from linkedlist import LinkedList