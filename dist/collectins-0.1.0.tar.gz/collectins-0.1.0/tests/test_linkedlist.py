from collectins.linkedlist import LinkedList

def test_append_single_element():
    l1 = LinkedList(1)
    l1.append(2)

    assert l1.head.val == 1
    assert l1.head.next.val == 2
    assert l1.head.next.next is None

def test_append_multiple_elememt():
    l1 = LinkedList(10)
    l1.append(20)
    l1.append(30)

    assert l1.head.val == 10
    assert l1.head.next.val == 20
    assert l1.head.next.next.val == 30